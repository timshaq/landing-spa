export default function() {

	$('#promodalGallery').fotorama({
		width: '100%',
		maxwidth: '100%',
		ratio: 16 / 9,
		allowfullscreen: true,
		nav: 'thumbs',
		thumbmargin: 20,
		swipe: true
	});

}